async function getAstronomi(){
 const key="<?php include 'konfigurasi/api_key.php'; ?>";
 const city=document.getElementById('cityInput').value;
 const geo=await fetch(`https://api.openweathermap.org/geo/1.0/direct?q=${city}&appid=${key}`);
 const g=await geo.json();
 const lat=g[0].lat, lon=g[0].lon;
 const r=await fetch(`https://api.openweathermap.org/data/3.0/onecall?lat=${lat}&lon=${lon}&appid=${key}`);
 const d=await r.json();
 document.getElementById("astro").innerHTML = `
   <p>Sunrise: ${new Date(d.current.sunrise*1000).toLocaleTimeString()}</p>
   <p>Sunset: ${new Date(d.current.sunset*1000).toLocaleTimeString()}</p>
   <p>Moon phase: ${d.daily[0].moon_phase}</p>
 `;
}