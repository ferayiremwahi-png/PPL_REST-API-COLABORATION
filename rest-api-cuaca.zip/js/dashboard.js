async function getWeather(){
 const key="<?php include 'konfigurasi/api_key.php'; ?>";
 const city=document.getElementById("cityInput").value;
 const r=await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${key}&units=metric`);
 const d=await r.json();
 document.getElementById("result").innerHTML = `
   <h2>${d.name}</h2>
   <p>Suhu: ${d.main.temp}°C</p>
   <p>Kondisi: ${d.weather[0].description}</p>
 `;
}