<nav>
<h1>WeatherNow</h1>
<a href='index.php'>Dashboard</a>
<a href='astronomi.php'>Astronomi</a>
</nav>