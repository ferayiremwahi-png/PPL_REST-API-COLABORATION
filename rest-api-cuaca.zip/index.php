<!DOCTYPE html>
<html lang='en'>
<head>
<meta charset='UTF-8'>
<title>WeatherNow - Dashboard</title>
<link rel='stylesheet' href='css/style.css'>
<script defer src='js/dashboard.js'></script>
</head>
<body>
<?php include 'konfigurasi/navbar.php'; ?>
<div class='search-box'>
  <input id='cityInput' placeholder='Cari kota...'>
  <button onclick='getWeather()'>Cari</button>
</div>
<div id='result'></div>
</body>
</html>
